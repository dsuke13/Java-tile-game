import javax.swing.JFrame; //フレームクラス
import javax.swing.JPanel; //パネルクラス

import java.util.Random; //乱数生成用

import java.awt.CardLayout; //カードレイアウトクラス
import java.awt.BorderLayout; //上下左右、中央に収まるようコンポーネントを整列およびサイズ変更して、コンテナに配置

public class MainFrame extends JFrame{

  //フィールド
    private static final long serialVersionUID = 1L; //警告を消すため(無視)

    JPanel cardPanel; //パネル写す元のパネルとなるcardPanelを生成
    CardLayout layout; //カードレイアウトの生成
    
   //各種パネルを作成
    StartPanel startPanel = new StartPanel(this);
    HelpPanel helpPanel = new HelpPanel(this);
    GamePanel gamePanel = new GamePanel(this);
    GameOverPanel overPanel = new GameOverPanel(this);
    GameClearPanel clearPanel = new GameClearPanel(this);

    Random rand = new Random(); //スコアの乱数
    int score = 0; //ベストスコア
    int nowscore = 0; //スコア

  //コンストラクタ
    public MainFrame(String title){
    
        this.setBounds(450,100,460,695); //windows画面上に左上から450,100の位置に460,695のフレームを生成
        this.setTitle(title);

        //透過処理
        startPanel.setOpaque(false);
        helpPanel.setOpaque(false);
        gamePanel.setOpaque(false);
        overPanel.setOpaque(false);
        clearPanel.setOpaque(false);

        //CardLayoutを使用(cardlayoutという配置方法を指定)
        startPanel.setLayout(new CardLayout());
        helpPanel.setLayout(new CardLayout());
        gamePanel.setLayout(new CardLayout());
        overPanel.setLayout(new CardLayout());
        clearPanel.setLayout(new CardLayout());

        
        cardPanel = new JPanel(); //このcardPanelにそれぞれの画面のパネルを登録
        cardPanel.setOpaque(false);

        layout = new CardLayout(); //カードレイアウトの生成
        cardPanel.setLayout(layout); //カードレイアウトをカードパネルに指定


        cardPanel.add(startPanel,"start");
        cardPanel.add(helpPanel,"help");
        cardPanel.add(gamePanel,"game");
        cardPanel.add(overPanel,"over");
        cardPanel.add(clearPanel,"clear");
        
        getContentPane().add(cardPanel,BorderLayout.CENTER); //カードはフレームの中心に配置
    }

    //メインメソッド
    public static void main(String[] args) {
        MainFrame mainFrame = new MainFrame("Shooting Game");

        mainFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        mainFrame.setVisible(true);
    }

    //移動用の各種メソッド
    public void ToStartCard(){
        layout.show(cardPanel,"start");
        startPanel.requestFocus();
    }

    public void ToHelpCard(){
        layout.show(cardPanel,"help");
        helpPanel.requestFocus();
    }

    public void ToGameCard(){
    
        layout.show(cardPanel,"game");
        gamePanel.requestFocus();
    }

    public void ToOverCard(){
        nowscore = rand.nextInt(100000);
        if(nowscore > score){
            score = nowscore;
        }

        layout.show(cardPanel,"over");
        overPanel.requestFocus(); 
    }

    public void ToClearCard(){
        nowscore = rand.nextInt(100000);
        if(nowscore > score){
            score = nowscore;
        }

        layout.show(cardPanel,"clear");
        clearPanel.requestFocus();
    }

    public void ToExit(){
        setVisible(false);
    }

    //スコア用の各種メソッド
    public int getScore(){
        return score;
    }

    public int getNowScore(){
        return nowscore;
    }

    public void setScore(int newscore){
        score = newscore;
    }
}
