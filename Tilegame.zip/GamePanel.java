import javax.swing.JPanel;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.*; //キーボードイベントのためのクラスをまとめてimport

import java.util.Random;

import java.io.*;
import java.lang.management.ThreadMXBean;
import java.awt.image.*; // 画像ファイルの取り扱い関係(1)
import javax.imageio.*; // 画像ファイルの取り扱い関係(2)

class GamePanel extends JPanel implements KeyListener, Runnable{ //JPanelを継承、keyListener,Runnableインターフェースを実装したパネルのクラス

  //フィールド
  private static final long serialVersionUID = 1L; //クラス名の警告を消すためのもの(無視でいい)

  MainFrame mainFrame; //メインフレームの読み込み

  // 二次元マップの準備
  private char map[][]; //マップとして配列mapを生成（privateは同一クラスからのみ許可)
  private int MX = 14, MY = 21; //MX:x軸の範囲(450-420)、MY:y軸の範囲(690-660) 上下15ずつ空白 30*30を一マスとする
  private String map_str[] = { //それぞれのマップのタイルにどういった物を配置するか指定
    "      E       ",
    "              ",
    "              ",
    "              ",
    "              ",
    "              ",
    "              ",
    "              ",
    "              ",
    "              ",
    "              ",
    "              ",
    "              ",
    "              ",
    "              ",
    "              ",
    "              ",
    "              ",
    "              ",
    "              ",
    "      M       "
  };
    
  //各種画像用
  private BufferedImage plane1Image, plane2Image;
  private BufferedImage backImage;
  private BufferedImage missile1Image, missile2Image;
  private BufferedImage meteo1Image, meteo2Image, meteo3Image, meteo4Image;

  //戦闘機の座標(タイル基準)
  private int plane1_x;
  private int plane1_y;

  private int plane2_x = 7; //初期位置
  private int plane2_y = 1;

  //ミサイルの座標(ピクセル基準)
  private int missile11_x;
  private int missile11_y;
  private int missile12_x; //二発目
  private int missile12_y;

  private int missile2_x;
  private int missile2_y;
 

  //隕石の座標(タイル基準)
  private int meteo_x;
  private int meteo_y;

  //乱数生成
  private Random rand = new Random();

  //ミサイル発射
  private int fire11 = 0; //味方機一発目
  private int fire12 = 0; //味方機二発目
  private int fire2 = 0; //敵機一発目
  private int meteofire = 0;

  private int move2;
  private int meteomove;
  private int meteoI;

  private Thread th; //敵機描画用

  private int onoff = 0;


  //コンストラクタ
  GamePanel(MainFrame mf){
    try {
      //画像の読み込み
      File plane1File = new File("./image/plane1.png"); //42*42
      File plane2File = new File("./image/plane2.png"); //42*42
      File backFile = new File("./image/back.png"); //460*695
      File missile1File = new File("./image/misa1.png");
      File missile2File = new File("./image/misa2.png");
      File meteo1File = new File("./image/meteo1.png");
      File meteo2File = new File("./image/meteo2.png");
      File meteo3File = new File("./image/meteo3.png");
      File meteo4File = new File("./image/meteo4.png");

      plane1Image = ImageIO.read(plane1File);
      plane2Image = ImageIO.read(plane2File);
      backImage = ImageIO.read(backFile);
      missile1Image = ImageIO.read(missile1File);
      missile2Image = ImageIO.read(missile2File);
      meteo1Image = ImageIO.read(meteo1File);
      meteo2Image = ImageIO.read(meteo2File);
      meteo3Image = ImageIO.read(meteo3File);
      meteo4Image = ImageIO.read(meteo4File);

    } catch (IOException e) {
      System.err.println("ファイルの読み込みに失敗しました．"); //該当画像がない時の例外処理
    }

    mainFrame = mf;

    map = new char[MX+1][MY+1];

    for (int x = 1; x <= MX; x++){
      map[x-1][0] = 'n';
    }

    for (int y = 1; y <= MY; y++){
      map[0][y-1] = 'n';
    }

    //マップデータの読み込み
    for (int x = 1; x <= MX; x++){
      for (int y = 1; y <= MY; y++){
        map[x][y] = map_str[y-1].charAt(x-1); //charAt:文字列からx個目の配列要素のy番目の文字を取り出す(x,yは反転する)
        if ( map[x][y] == 'M') { //M(味方機)の位置をx,y座標と置く。
          plane1Set(x, y);
        }
        if ( map[x][y] == 'E') { //E(敵機)の位置をx,y座標と置く。
          plane2Set(x, y);
        }
      }
    }

    th = new Thread(this);
    th.start();
  
    addKeyListener(this); // KeyListenerのリスナーオブジェクトをpanelに登録する
    setFocusable(true); // JPanelでキーボード入力を受け付けるようフォーカスを当てる
  }
  
  
  // 描画処理
  @Override //JPanelクラスより
  public void paintComponent(Graphics g){ //それぞれをどのように描画するか指定
    g.drawImage(backImage, 0, 0, this);
    
    g.setColor(Color.white);
    g.drawLine(7,7,7,653);
    g.drawLine(7,7,442,7);
    g.drawLine(442,7,442,653);
    g.drawLine(7,653,442,653);

    /**for (int y = 1; y <= MY; y++) {
      for (int x = 1; x <= MX; x++) {
        int xx = 30 * x - 15;
        int yy = 30 * y - 15;

        g.drawLine(xx,yy,xx,yy+30); //左線
        g.drawLine(xx,yy,xx+30,yy); //上線
        g.drawLine(xx+30,yy,xx+30,yy+30); //右線
        g.drawLine(xx,yy+30,xx+30,yy+30); //下線
      }
    }*/

    missile1Draw(g); //味方ミサイルの描画
    missile2Draw(g); //敵機ミサイルの描画
    plane1Draw(g); //味方機の描画
    plane2Draw(g); //敵機の描画
    meteoDraw(g); //隕石の描画
  }

  

  @Override
  public void keyPressed(KeyEvent e){ 
    char key = e.getKeyChar();
    int key2 = e.getKeyCode();

    if (key == 'w'){
      if(plane1_y > 11)
        plane1_y -= 1;
    }
    if (key == 's'){
      if(plane1_y < MY)
        plane1_y += 1;
    }
    if (key == 'd'){
      if(plane1_x < MX)
        plane1_x += 1;
    }
    if (key == 'a'){
      if(plane1_x > 1)
        plane1_x -= 1;
    }
    if (key2 == KeyEvent.VK_ENTER){
      if(fire11 == 0 && fire12 == 0){
        fire11 = 1;
        missile11_x = (30*plane1_x) - 7;
        missile11_y = 30*(plane1_y - 1); //戦闘機の一つ上のタイルから描画するため
      }

      else if(fire11 == 1 && fire12 == 0){
        fire12 = 1;
        missile12_x = (30*plane1_x) - 7;
        missile12_y = 30*(plane1_y - 1); //戦闘機の一つ上のタイルから描画するため
      }

      else{
        missile11_x = (30*plane1_x) - 7;
        missile11_y = 30*(plane1_y - 1); //戦闘機の一つ上のタイルから描画するため
      }
    }
    repaint();
  }
  
      
  public void keyReleased(KeyEvent e){}
  
  public void keyTyped(KeyEvent e) {}

  public void run(){
    while(onoff == 0){
      plane2Move();
      try{
        Thread.sleep(200);
        }catch(InterruptedException e){
      }
      repaint();
    }
  }


  public void plane1Set(int x, int y){
    plane1_x = x;
    plane1_y = y;
  }

  public void plane2Set(int x, int y){
    plane2_x = x;
    plane2_y = y;
  }

  
  
  public void plane1Draw(Graphics g){
    g.drawImage(plane1Image, 30*plane1_x-21, 30*plane1_y-21, this);
  }

  public void plane2Draw(Graphics g){
    g.drawImage(plane2Image, 30*plane2_x-21, 30*plane2_y-21, this);
  }

  public void plane2Move(){
    move2 = rand.nextInt(4);

    if(move2 == 0){
      if(plane2_x < 14){
        plane2_x++;
      }
      else
        plane2_x--;
    }
    else if(move2 == 1){
      if(plane2_x > 1){
        plane2_x--;
      }
      else
        plane2_x++;
    }

    else if(move2 == 2){
      if(plane2_y < 10){
        plane2_y++;
      }
    }

    else if(move2 == 3){
      if(plane2_y > 1){
        plane2_y--;
      }
    }
  }

  public void missile1Draw(Graphics g){
    if(fire11 == 1){

      if(missile11_y > 10){
        missile11_y = missile11_y - 10;

        g.drawImage(missile1Image, missile11_x, missile11_y, this);

        if(missile11_x == 30*plane2_x - 7 && missile11_y == plane2_y*30 + 20){
          
          for (int x = 1; x <= MX; x++){
            for (int y = 1; y <= MY; y++){
              map[x][y] = map_str[y-1].charAt(x-1); //charAt:文字列からx個目の配列要素のy番目の文字を取り出す(x,yは反転する)
              if(map[x][y] == 'M'){ //M(主人公)の位置をx,y座標と置く。
                plane1Set(x, y);
              }
              if(map[x][y] == 'E'){
                plane2Set(x, y);
              }
            }
          }
  
          fire11 = 0;
          fire12 = 0;

          mainFrame.ToClearCard();
        }
        repaint();
      }

      else{
        fire11 = 0; //y座標の上限を超えたら発射をリセット
      }
    }

    if(fire12 == 1){

      if(missile12_y > 5){
        missile12_y = missile12_y - 10;

        g.drawImage(missile1Image, missile12_x, missile12_y, this);

        if(missile12_x == 30*plane2_x - 7 && missile12_y == plane2_y*30 + 20){
          
          for (int x = 1; x <= MX; x++){
            for (int y = 1; y <= MY; y++){
              map[x][y] = map_str[y-1].charAt(x-1); //charAt:文字列からx個目の配列要素のy番目の文字を取り出す(x,yは反転する)
              if ( map[x][y] == 'M') { //M(主人公)の位置をx,y座標と置く。
                plane1Set(x, y);
              }
              if(map[x][y] == 'E'){
                plane2Set(x, y);
              }
            }
          }
          plane2_x = 7;
          plane2_y = 1;


          fire11 = 0;
          fire12 = 0;
          meteofire = 0;

          mainFrame.ToClearCard();
        }
        repaint();
      }

      else{
        fire12 = 0; //y座標の上限を超えたら発射をリセット
      }
    }
  }

  public void missile2Draw(Graphics g){
    if(fire2 == 1){

      if(missile2_y < 680){
        missile2_y = missile2_y + 10;

        g.drawImage(missile2Image, missile2_x, missile2_y, this);

        if(missile2_x == 30*plane1_x - 7 && missile2_y == plane1_y*30 + 10){
          
          for (int x = 1; x <= MX; x++){
            for (int y = 1; y <= MY; y++){
              map[x][y] = map_str[y-1].charAt(x-1); //charAt:文字列からx個目の配列要素のy番目の文字を取り出す(x,yは反転する)
              if ( map[x][y] == 'M') { //M(主人公)の位置をx,y座標と置く。
                plane1Set(x, y);
              }
              if(map[x][y] == 'E'){
                plane2Set(x, y);
              }
            }
          }
          plane2_x = 7;
          plane2_y = 1;

          fire11 = 0;
          fire12 = 0;
          meteofire = 0;

          mainFrame.ToOverCard();
        }

        repaint();
      }
      else{
        fire2 = 0;
      }

    }

    else if(fire2 == 0){
      fire2 = 1;
      missile2_x = (30*plane2_x) - 7;
      missile2_y = 30*(plane2_y + 1);
    }
  }

  public void meteoDraw(Graphics g){
    if(meteofire == 1){
      if(meteo_y < 680){
        meteo_y = meteo_y + 6;

        if(meteoI < 20){
          g.drawImage(meteo1Image, meteo_x, meteo_y, this);
          meteoI++;
        }

        else if(meteoI < 40){
          g.drawImage(meteo2Image, meteo_x, meteo_y, this);
          meteoI++;
        }

        else if(meteoI < 60){
          g.drawImage(meteo3Image, meteo_x, meteo_y, this);
          meteoI++;
        }

        else if(meteoI < 80){
          g.drawImage(meteo4Image, meteo_x, meteo_y, this);
          meteoI = 0;
        }

        if(meteo_x == 30*plane1_x -21  && meteo_y == plane1_y*30 - 14){
          
          for (int x = 1; x <= MX; x++){
            for (int y = 1; y <= MY; y++){
              map[x][y] = map_str[y-1].charAt(x-1); //charAt:文字列からx個目の配列要素のy番目の文字を取り出す(x,yは反転する)
              if ( map[x][y] == 'M') { //M(主人公)の位置をx,y座標と置く。
                plane1Set(x, y);
              }
            }
          }
          plane2_x = 7;
          plane2_y = 1;

          fire11 = 0;
          fire12 = 0;
          meteofire = 0;

          mainFrame.ToOverCard();
        }

        repaint();
      }
      else{
        meteofire = 0;
        meteoI = 0;
      }
    }
    else if(meteofire == 0){
      meteomove = 1 + rand.nextInt(14);

      meteofire = 1;
      meteo_x = 30*meteomove - 21;
      meteo_y = 10;
    }
  }
}