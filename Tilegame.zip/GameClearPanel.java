import javax.swing.JPanel;

import java.awt.Font;
import java.awt.FontFormatException;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.*; //キーボードイベントのためのクラス

import java.io.*; //ファイルを読み書き
import java.awt.image.*; // 画像ファイルを表示する
import javax.imageio.*; // 画像ファイルを読み書き

class GameClearPanel extends JPanel implements KeyListener{

  private static final long serialVersionUID = 1L;

  // フィールド
  MainFrame mainFrame;
  Font font,font2,font3,font4; //コンストラクタ外でも使うため
  int choice = 400;

  BufferedImage backImage;
  
  // コンストラクタ
  GameClearPanel(MainFrame mf){ //こちらのclassでmainFrameを使うために必要
    
    try{
      font = Font.createFont(Font.TRUETYPE_FONT,new File("./font/PixelMplus12-Regular.ttf"));
      font2 = Font.createFont(Font.TRUETYPE_FONT,new File("./font/PixelMplus10-Regular.ttf"));
      }catch(FontFormatException e){
      System.out.println("形式がフォントではありません。");
      }catch(IOException e){
      System.out.println("入出力エラーでフォントを読み込むことができませんでした。");
    }

    try {
      //画像の読み込み
      File backFile = new File("./image/back.png"); //gifで主人公を取得(簡単に描画出来ないもの)
      backImage = ImageIO.read(backFile); //boyImgにgif画像を入力
    } catch (IOException e) {
      System.err.println("ファイルの読み込みに失敗しました．"); //gifがない時の例外処理
  }

    font3 = font2;
    font4 = font2;

    font = font.deriveFont(56f); //fontサイズを変更
    font2 = font2.deriveFont(40f);
    font3 = font3.deriveFont(35f);
    font4 = font4.deriveFont(25f);

    mainFrame = mf;

    this.setOpaque(false);

    addKeyListener(this); // KeyListenerのリスナーオブジェクトをこのパネルに登録する
    setFocusable(true); // このパネルでキーボード入力を受け付けるようフォーカスを当てる
  }
  
  // 描画処理
  @Override //JPanelクラスより
  public void paintComponent(Graphics g){ //それぞれをどのように描画するか指定
    g.drawImage(backImage,0,0,this);

    g.setColor(Color.red);

    g.setFont(font);
    g.drawString("GAME CLEAR!!",80,200);

    g.setColor(Color.white);

    g.drawLine(7,7,7,653);
    g.drawLine(7,7,442,7);
    g.drawLine(442,7,442,653);
    g.drawLine(7,653,442,653);

    g.setFont(font2);

    g.drawString(" Score  :",60, 280);
    g.drawString(String.format("%06d", mainFrame.getNowScore()),282, 280);

    g.setFont(font3);
  
    g.drawString("Retry", 170,400);
    g.drawString("Exit",170,440);
    g.drawString(">",128,choice);

    g.setFont(font4);
    g.drawString("(R)",268,400);
    g.drawString("(E)",268,440);
  }

  
  // KeyListenerのメソッドkeyPressed
  @Override
  public void keyPressed(KeyEvent e){ 
    int key = e.getKeyCode();

    if(key == KeyEvent.VK_ENTER){
      if(choice == 400){
        mainFrame.ToStartCard();
      }
      
      if(choice == 440){
        mainFrame.ToExit();
      }
    }

    if(key == KeyEvent.VK_UP){
      if (choice > 400){
        choice = choice - 40;
        repaint();
      }
    }

    if(key == KeyEvent.VK_DOWN){
      if(choice < 440){
        choice = choice + 40;
        repaint();
      }
    }
  }
  
  //KeyListenerのメソッドkeyReleased
  @Override
  public void keyReleased(KeyEvent e){ }
  
  // KeyListenerのメソッドkeyTyped
  @Override
  public void keyTyped(KeyEvent e){
    char key = e.getKeyChar();
    
    if (key == 'r'){
      mainFrame.ToStartCard();
    }

    if (key == 'e'){
      mainFrame.ToExit();
    }
  }
}