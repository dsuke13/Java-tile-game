import javax.swing.JPanel;

import java.awt.Font;
import java.awt.FontFormatException;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.*; //キーボードイベントのためのクラス

import java.io.*; //ファイルを読み書き
import java.awt.image.*; // 画像ファイルを表示する
import javax.imageio.*; // 画像ファイルを読み書き

class HelpPanel extends JPanel implements KeyListener{

  private static final long serialVersionUID = 1L;

  // フィールド
  MainFrame mainFrame;
  Font font,font2,font3,font4; //コンストラクタ外でも使うため
  private BufferedImage backImage; //背景画像
  private BufferedImage plane1Image;
  private BufferedImage plane2Image;
  private BufferedImage meteoImage;
  private BufferedImage missileImage;
  
  // コンストラクタ
  HelpPanel(MainFrame mf){ //こちらのclassでmainFrameを使うために必要
    
    try{
      font = Font.createFont(Font.TRUETYPE_FONT,new File("./font/PixelMplus12-Regular.ttf"));
      font2 = Font.createFont(Font.TRUETYPE_FONT,new File("./font/PixelMplus10-Regular.ttf"));
      }catch(FontFormatException e){
      System.out.println("形式がフォントではありません。");
      }catch(IOException e){
      System.out.println("入出力エラーでフォントを読み込むことができませんでした。");
    }

    try {
      File backFile = new File("./image/back.png");
      File plane1File = new File("./image/plane1.png");
      File plane2File = new File("./image/plane2.png");
      File meteoFile = new File("./image/meteo1.png");
      File missileFile = new File("./image/misa1.png");
      backImage = ImageIO.read(backFile);
      plane1Image = ImageIO.read(plane1File);
      plane2Image = ImageIO.read(plane2File);
      meteoImage = ImageIO.read(meteoFile);
      missileImage = ImageIO.read(missileFile);
    } catch (IOException e) {
      System.err.println("ファイルの読み込みに失敗しました．"); //gifがない時の例外処理
    }

    font3 = font2;
    font4 = font2;

    font = font.deriveFont(56f); //fontサイズを変更
    font2 = font2.deriveFont(35f);
    font3 = font3.deriveFont(30f);
    font4 = font4.deriveFont(25f);

    mainFrame = mf;

    this.setOpaque(false);

    addKeyListener(this); // KeyListenerのリスナーオブジェクトをこのパネルに登録する
    setFocusable(true); // このパネルでキーボード入力を受け付けるようフォーカスを当てる
  }
  
  // 描画処理
  @Override //JPanelクラスより
  public void paintComponent(Graphics g){ //それぞれをどのように描画するか指定
    g.drawImage(backImage, 0, 0, this);

    g.drawImage(plane1Image,330,170,this);
    g.drawImage(plane1Image,330,210,this);
    g.drawImage(plane1Image,330,250,this);
    g.drawImage(plane1Image,330,290,this);

    g.drawImage(missileImage,320,345,this);
    g.drawImage(missileImage,340,345,this);
    g.drawImage(missileImage,360,345,this);

    g.drawImage(plane2Image,240,450,this);
    g.drawImage(meteoImage,240,500,this);
    
    g.setColor(Color.white);

    g.drawLine(7,7,7,653);
    g.drawLine(7,7,442,7);
    g.drawLine(442,7,442,653);
    g.drawLine(7,653,442,653);

    g.setFont(font);
    g.drawString("Help Menu",90,100);

    g.setFont(font2);
    g.drawString("Operation",70,160);
    g.drawString("Enemy",70,440);

    g.drawString("Back", 170,600);
    g.drawString(">",128,600);

    g.setFont(font3);
    g.drawString("  W  : move ↑",110,200);
    g.drawString("  D  : move →",110,240);
    g.drawString("  A  : move ←",110,280);
    g.drawString("  S  : move ↓",110,320);

    g.drawString("ENTER: shot!!",110,370);

    g.drawString("Plane:",110,480);
    g.drawString("Meteo:",110,525);

    g.setFont(font4);
    g.drawString("(B)",248,600);
  }
  // KeyListenerのメソッドkeyPressed
  @Override
  public void keyPressed(KeyEvent e){ 
    int key = e.getKeyCode();

    if(key == KeyEvent.VK_ENTER){
        mainFrame.ToStartCard();
      }
  }
  
  //KeyListenerのメソッドkeyReleased
  @Override
  public void keyReleased(KeyEvent e){ }
  
  // KeyListenerのメソッドkeyTyped
  @Override
  public void keyTyped(KeyEvent e){
    char key = e.getKeyChar();
    
    if (key == 'b'){
      mainFrame.ToStartCard();
    }
  }
}